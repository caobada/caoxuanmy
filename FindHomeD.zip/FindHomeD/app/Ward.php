<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ward extends Model
{
    //
    public $remember_token = false;
    protected $table="Ward";
}
