<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Province extends Model
{
    //
    public $remember_token = false;
    protected $table ="Province";
    public function District(){
    
    }
  
}
