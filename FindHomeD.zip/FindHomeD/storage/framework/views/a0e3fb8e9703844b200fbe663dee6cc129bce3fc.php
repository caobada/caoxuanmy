<?php $__env->startSection('link'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery.dataTables.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-top: 20px;">
	<div class="row">
		<table id="table_id" class="display">
			

			<thead>
				<tr>
					<th>ID</th>
					<th>Tiêu Đề</th>
					<th>Danh mục</th>
					<th>Giá</th>
					<th>Phone</th>
					<th>Ngày đăng</th>
					<th></th>
					
				</tr>
			</thead>
			<tbody>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($data->home_id); ?></td>
					<td><?php echo e($data->title); ?></td>
					<td><?php echo e($data->hometype->nametype); ?></td>
					<td><?php                                      
                                    $var = explode("@",$data->price);
                                    if($var[1]==1) echo  number_format($var[0])." Nghìn/tháng";
                                    else echo $var[0].' Triệu/tháng';
                                    ?></td>
					<td><?php echo e($data->phone_home); ?></td>
					<td><?php echo e($data->created_at); ?></td>
					<td>Xóa</td>
				</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.dataTables.js')); ?>"></script>
<script type="text/javascript">
	$(function(){
		$("#table_id").dataTable();
	})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wrapper', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>