<?php $__env->startSection('content'); ?>

<!-- Hiển thị các phòng trọ -->
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="Main-title">
                <p><u>Tin nổi bật</u></p>
            </div>
            <div class="row">
                <!-- Item-->
                <?php $__currentLoopData = $top6post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top6post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-6 col-xm-12">
                    <div class="media Item">
                        <div class="pull-left">
                            <?php
                            $img = explode(";",$top6post->image);
                            $numpic = count($img);
                            
                            ?>
                            <div class="media-object" style='background-image: url(<?php echo e(asset("images/home/$img[0]")); ?>)'>
                                <div class="numpic"><?php echo e($numpic); ?> ảnh</div>
                            </div>
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading"><a href='<?php echo e(url("detail/$top6post->home_id")); ?>'><?php echo e($top6post->title); ?></a></h4>
                            <div class="clearfix">
                                <div class="btn price">
                                    <?php                                      
                                    $var = explode("@",$top6post->price);
                                    if($var[1]==1) echo  number_format($var[0])." Nghìn/tháng";
                                    else echo $var[0].' Triệu/tháng';
                                    ?>
                                </div>
                                <div class="area"><b><?php echo e($top6post->area); ?>m<sup>2</sup></b></div>
                                <div class="location"><b><?php echo e($top6post->districted->type); ?> <?php echo e($top6post->districted->name); ?>, <?php echo e($top6post->province->name); ?></b></div>
                            </div>
                            <div class="by-author"><p >
                                <?php 
                                $lenght = str_word_count($top6post->desc);
                                if($lenght>40) echo strip_tags(substr($top6post->desc, 0,120)).'...';
                                else echo strip_tags($top6post->desc);
                                ?>
                            </p></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!--end Item -->
                
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('subpage.left-main-content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wrapper', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>