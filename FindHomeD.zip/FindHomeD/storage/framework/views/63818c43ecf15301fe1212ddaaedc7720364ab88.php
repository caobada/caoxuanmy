<?php $__env->startSection('link'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery.dataTables.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-top: 20px;">
	<div class="row">
		<table id="table_id" class="display">
			<a href="export-database"><input type="button" name="" class="btn btn-success" value="Export Excel">
			<input type="button" name="" class="btn btn-success" value="Import Excel" style="margin: 20px 20px 20px 10px">
			<thead>
				<tr>
					<th>ID</th>
					<th>username</th>
					<th>status</th>
					<th>phone</th>
					<th></th>
					
				</tr>
			</thead>
			<tbody>
			<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($user->id); ?></td>
					<td><?php echo e($user->username); ?></td>
					<td><?php echo e($user->status); ?></td>
					<td><?php echo e($user->phone); ?></td>
					<td>Xóa</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.dataTables.js')); ?>"></script>
<script type="text/javascript">
	$(document).ready( function () {
		$('#table_id').DataTable();

		$('#import').click(function(){
		$('#form').fadeToggle();
	});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wrapper', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>