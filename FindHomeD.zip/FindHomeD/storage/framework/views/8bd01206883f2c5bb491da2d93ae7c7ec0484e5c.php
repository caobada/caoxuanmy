<!DOCTYPE html>
<html>
<head>
	<title>FindHomeD</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<?php echo $__env->yieldContent('link'); ?>

	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>" >
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
	<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/mystyle.css')); ?>">
	<link href="<?php echo e(asset('vendor/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/icomoon.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/animate.css')); ?>">

	
	<style type="text/css">
	*{
		font-family: Tahoma, Arial, sans-serif;

	}
</style>
</head>
<body>

	<div id="page">
		<nav class="fh5co-nav" role="navigation">
			<div class="top" id="top">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 text-right">
							<p class="num">Call: +0961467216</p>
							<ul class="fh5co-social">
								<?php if(Auth::check()): ?>
								<p><span class="title">Xin chào <?php echo e(Auth::user()->username); ?></span> |||<a id="logout" href="<?php echo e(route('logout')); ?>"><i class="fa fa-sign-out"></i></a></p>

								<?php else: ?>
								<li><a href="#" data-toggle="modal" data-target="#exampleModalCenter">Đăng nhập</a></li>
								<?php endif; ?>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="top-menu">
				<div class="container">
					<div class="row">
						<div class="col-xs-2">
							<div id="fh5co-logo"><a href="<?php echo e(url('/')); ?>">Find<span>HomeD.</span></a></div>
						</div>
						<div class="col-xs-10 text-right menu-1">
							<ul>
								<li class="active"><a href="<?php echo e(url('/')); ?>">Home</a></li>
								<li class="has-dropdown" >
									<a href="#">Danh mục thuê</a>
									<ul class="dropdown">
										<?php $__currentLoopData = $hometype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li><a href='<?php echo e(url("type/$menu->nametypelink")); ?>'><?php echo e($menu->nametype); ?></a></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									</ul>
								</li>
								<li><?php if(Auth::check()): ?><a href="<?php echo e(url('posthome')); ?>"><?php else: ?> <a href="#" data-toggle="modal" data-target="#exampleModalCenter"> <?php endif; ?> Đăng tin</a></li>
								<?php if(Auth::check()): ?><li><a href="<?php echo e(url('quan-ly-bai-dang')); ?>">Quản lý bài đăng</a></li><?php endif; ?>

								<li><a href="#">Liên hệ</a></li>

							</ul>
						</div>
					</div>

				</div>
			</div>
		</nav>

		<header id="fh5co-header" class="fh5co-cover" role="banner" style='background-image:url(<?php echo e(asset("images/bbb.jpg")); ?>' data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeIn">
								<h1><span style="color:#000;font-weight: 700">find</span><span  style="color:#F85A16;font-weight: 700 ">homeD</span></h1>
								<h2>Website tìm kiếm phòng trọ uy tín số 1 Việt Nam</h2>

							</div>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- Services -->
		<section style="padding: 0px;margin: 0px ">
			<div class="container ">
				<div class="searchbar ">
					<div class="row ">
						<div class="col-lg-12 a"> 
							<div>
								<div class="filter "><b>LỌC TIN NHANH</b></div>
								<div class="row " style=" ">
									<form id="form-search" method="get" action="<?php echo e(url('search')); ?>" >
										<div class="col-lg-2 ">
											<span class="badge ">Loại tin</span>
											<select class="form-control select" name="type">
												<option value="">Chọn loại tin</option>
												<?php $__currentLoopData = $hometype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hometype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option <?php if(isset($_GET['type'])){if($hometype->id==$_GET['type']) echo "selected='selected'";} ?> value="<?php echo e($hometype->id); ?>"><?php echo e($hometype->nametype); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
										<!-- Tỉnh thành  -->
										<div class="col-lg-2 ">
											<span class="badge ">Tỉnh thành</span>
											<select id="province" class="form-control " name="province">
												<option value="">Tất cả</option>
												<?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option <?php if(isset($_GET['province'])){if($province->provinceid==$_GET['province']) echo "selected='selected'";} ?>  value="<?php echo e($province->provinceid); ?>"><?php echo e($province->name); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
										<!-- Quận huyện -->
										<div  class="col-lg-2 ">
											<span class="badge ">Quận huyện</span>
											<select id="district" class="form-control " name="district">
												<option value="">Tất cả</option>
											</select>
										</div>
										<!-- Khoảng giá -->
										<div class="col-lg-2 ">
											<span class="badge ">Khoảng giá</span>
											<select class="form-control " name="price">
												<option value="">Tất cả</option>
												<option value="1">Dưới 1 triệu</option>
												<option value="2">Từ 1->2 triệu</option>
												<option value="3">Từ 2->5 triệu</option>
												<option value="4">Trên 5 triệu</option>
											</select>
										</div>
										<!-- Diện tích -->
										<div class="col-lg-2 ">
											<span class="badge ">Diện tích</span>
											<select class="form-control " name="area">
												<option  value="">Tất cả</option>
												<option <?php if(isset($_GET['area'])){if ($_GET['area']==1) echo "selected='selected'";} ?> value="1">Dưới 10m<sub>2</sub></option>
												<option <?php if(isset($_GET['area'])){if ($_GET['area']==2) echo "selected='selected'";} ?> value="2">10m2 tới 30m2</option>
												<option <?php if(isset($_GET['area'])){if ($_GET['area']==3) echo "selected='selected'";} ?> value="3">Trên 30m2</option>
											</select>
										</div>
										<!--  Button -->
										<div class="col-lg-2 ">
											<span class="badge " ">&nbsp;</span>
											<button class="btn btn-warning" style="margin-top: 20px;">
												<i class="fa fa-filter"></i> Lọc tin
											</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<?php echo $__env->yieldContent('content'); ?>

	</div>
	<div>

		<?php echo $__env->make('subpage.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
	<div class="gototop js-top">
		<a href="#top" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	<script  src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" ></script>	 
	<script type="text/javascript" src="<?php echo e(asset('js/jquery.validate.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
	



	<!-- Modal -->
	<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">

					<h5 class="modal-title" id="exampleModalLongTitle">Đăng nhập</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<form method="post"  id="form-login">
					<div class="modal-body">

						<div class="info"></div>
						<div class="form-group" style="width: 200px;">
							<input type="text" name="username" class="form-control" maxlength="10" size="10" placeholder="Username">
						</div>
						<div class="form-group" style="width: 200px;">
							<input type="password" name="password" class="form-control" placeholder="Password">
							<?php echo e(csrf_field( )); ?>

						</div>

						<p>Nếu chưa có tài khoản?<a id="dangki" href="<?php echo e(url('register')); ?>"> Đăng ký</a></p>
					</div>
					<div class="login-social">
						<div class="container">
							<a class="btn  btn-social btn-facebook">
								<i class="fa fa-facebook fa-fw"></i> Đăng nhập với Facebook
							</a>
							<a class="btn btn-social btn-google">
								<i class="fa fa-google fa-fw"></i> Đăng nhập với Google
							</a>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal" style="color:black">Đóng</button>
						<button type="submit" class="btn btn-primary">Đăng nhập</button>
					</div>
				</form>
			</div>
		</div>
	</div>



</body>
</html>
<script type="text/javascript">
	var offcanvasMenu = function() {

		$('#page').prepend('<div id="fh5co-offcanvas" />');
		$('#page').prepend('<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle fh5co-nav-white"><i></i></a>');
		var clone1 = $('.menu-1 > ul').clone();
		$('#fh5co-offcanvas').append(clone1);
		var clone2 = $('.menu-2 > ul').clone();
		$('#fh5co-offcanvas').append(clone2);

		$('#fh5co-offcanvas .has-dropdown').addClass('offcanvas-has-dropdown');
		$('#fh5co-offcanvas')
		.find('li')
		.removeClass('has-dropdown');

		// Hover dropdown menu on mobile
		$('.offcanvas-has-dropdown').mouseenter(function(){
			var $this = $(this);

			$this
			.addClass('active')
			.find('ul')
			.slideToggle();				
		}).mouseleave(function(){

			var $this = $(this);
			$this
			.removeClass('active')
			.find('ul').slideToggle();

						
		});


		$(window).resize(function(){

			if ( $('body').hasClass('offcanvas') ) {

				$('body').removeClass('offcanvas');
				$('.js-fh5co-nav-toggle').removeClass('active');
				
			}
		});
	};
	$(function(){



		$("#logout").on('click',function(event){
			var kq = confirm("Bạn muốn đăng xuất?");
			if(kq==false) event.preventDefault();
		})

		$('#form-login').validate({
			rules:{
				username:{
					required:true,
					minlength:5
				},
				password:{
					required:true,
					minlength:5
				}

			},
			messages:{
				username:{
					required:"Yêu cầu nhập tên đăng nhập!",
					minlength:"Tên đăng nhập tối thiểu 5 kí tự!"
				},
				password:{
					required:"Yêu cầu nhập tên đăng nhập!",
					minlength:"Mật khẩu tối thiểu 5 kí tự!"
				}
			},
			submitHandler: checklogin
		});
			$("#form-search").validate({
			rules:{
				type:{
					required:true
				}
			},
			messages:{
				type:{
					required:"Chọn loại tin cần lọc!"
				}
			}
		});
		function checklogin(){
			var data = $("#form-login").serialize();
			$.ajax({
				type:'post',
				url:"<?php echo e(asset('login')); ?>",
				data:data,
				beforeSend:function(){
					$('.info').fadeOut();
				},
				success: function(resp){

					if(resp.error==false)
						setTimeout('location.href="http://localhost/FindHomeD/public",4000');
					else{
						$(".info").fadeIn(500,function(){
							$('.info').html(resp.message);
						});

					}

				}
			});
		}

		offcanvasMenu();
		
		$('#province').on('change',function(){
			var provinceid = $(this).val();
			var href = window.location.href;
			var array = href.split("/");
			var len = array.length
			if(len==6) url = 'province/'+ provinceid;
			else url = '../province/'+ provinceid
				if(provinceid=="") provinceid=0;
			$.ajax({
				type: 'GET',
				url : url ,
				success:function(resp){
					$("#district").html(resp);

				}
			});
		});
		
		$('body').on('click', '.js-fh5co-nav-toggle', function(event){
			var $this = $(this);


			if ( $('body').hasClass('overflow offcanvas') ) {
				$('body').removeClass('overflow offcanvas');
			} else {
				$('body').addClass('overflow offcanvas');
			}
			$this.toggleClass('active');
			event.preventDefault();

		});
		$(window).resize(function(){

			if ( $('body').hasClass('offcanvas') ) {

				$('body').removeClass('offcanvas');
				$('.js-fh5co-nav-toggle').removeClass('active');
				
			}
		});	



		$(window).scroll(function(){

			var $win = $(window);
			if ($win.scrollTop() > 200) {
				$('.js-top').addClass('active');
			} else {
				$('.js-top').removeClass('active');
			}

		});
		$("a").on('click', function(event) {


			if (this.hash !== "") {
				event.preventDefault();
				var hash = this.hash;
				$('html, body').animate({
					scrollTop: $(hash).offset().top 
				}, 800)
			}
		});	



		$('.has-dropdown').mouseenter(function(){

			$(this).find('.dropdown').css('display', 'block').addClass('animated-fast fadeInUpMenu');
		});
		$('.has-dropdown').mouseleave(function(){
			$(this).find('.dropdown').css('display', 'none').removeClass('animated-fast fadeInUpMenu');


		});


	});
</script>

<?php echo $__env->yieldContent('script'); ?>
