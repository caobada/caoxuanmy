@extends('wrapper')
@section('link')
	<link rel="stylesheet" type="text/css" href="{{asset('css/jquery.dataTables.css')}}">
@endsection
@section('content')
	<div class="container" style="margin-top: 20px;">
	<div class="row">
		<table id="table_id" class="display">
			<a href="export-database"><input type="button" name="" class="btn btn-success" value="Export Excel">
			<input type="button" name="" class="btn btn-success" value="Import Excel" style="margin: 20px 20px 20px 10px">
			<thead>
				<tr>
					<th>ID</th>
					<th>username</th>
					<th>status</th>
					<th>phone</th>
					<th></th>
					
				</tr>
			</thead>
			<tbody>
			@foreach($user as $user)
				<tr>
					<td>{{$user->id}}</td>
					<td>{{$user->username}}</td>
					<td>{{$user->status}}</td>
					<td>{{$user->phone}}</td>
					<td>Xóa</td>
				</tr>
			@endforeach
			</tbody>
		</table>
	</div>
</div>
@endsection

@section('script')
<script type="text/javascript" src="{{asset('js/jquery.dataTables.js')}}"></script>
<script type="text/javascript">
	$(document).ready( function () {
		$('#table_id').DataTable();

		$('#import').click(function(){
		$('#form').fadeToggle();
	});
	});
</script>
@endsection